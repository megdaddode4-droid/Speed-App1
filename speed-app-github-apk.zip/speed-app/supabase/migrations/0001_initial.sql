create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text not null unique,
  full_name text,
  role text not null default 'customer' check (role in ('customer','driver','admin')),
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.drivers (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','approved','rejected','suspended')),
  online boolean not null default false,
  active boolean not null default true,
  rating numeric(3,2) not null default 5.00 check (rating between 0 and 5),
  total_trips integer not null default 0 check (total_trips >= 0),
  license_number text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.drivers(id) on delete cascade,
  type text not null check (type in ('bike','scooter','bicycle')),
  make text, model text, color text, plate_number text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  driver_id uuid references public.drivers(id),
  type text not null check (type in ('ride','delivery')),
  status text not null default 'pending' check (status in ('pending','searching_driver','driver_assigned','driver_arriving','arrived_pickup','picked_up','on_the_way','arrived_destination','completed','cancelled')),
  pickup_lat double precision not null check (pickup_lat between -90 and 90),
  pickup_lng double precision not null check (pickup_lng between -180 and 180),
  destination_lat double precision not null check (destination_lat between -90 and 90),
  destination_lng double precision not null check (destination_lng between -180 and 180),
  distance_km numeric(10,2) not null check (distance_km >= 0),
  duration_min integer not null check (duration_min >= 0),
  estimated_fare numeric(12,2) not null check (estimated_fare >= 0),
  final_fare numeric(12,2) check (final_fare is null or final_fare >= 0),
  payment_method text not null default 'cash' check (payment_method in ('cash','mobile_money','bank_transfer','online')),
  delivery_category text,
  notes text,
  cancelled_by uuid references public.profiles(id),
  cancellation_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.trips (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  driver_id uuid not null references public.drivers(id),
  started_at timestamptz,
  arrived_pickup_at timestamptz,
  picked_up_at timestamptz,
  arrived_destination_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.locations (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.drivers(id) on delete cascade,
  order_id uuid references public.orders(id) on delete set null,
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  accuracy_m numeric(8,2),
  created_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  method text not null check (method in ('cash','mobile_money','bank_transfer','online')),
  amount numeric(12,2) not null check (amount >= 0),
  status text not null default 'pending' check (status in ('pending','paid','failed','refunded')),
  provider text,
  provider_reference text,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.ratings (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  customer_id uuid not null references public.profiles(id),
  driver_id uuid not null references public.drivers(id),
  rating integer not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.pricing (
  id uuid primary key default gen_random_uuid(),
  base_fare numeric(12,2) not null default 1000,
  price_per_km numeric(12,2) not null default 450,
  price_per_minute numeric(12,2) not null default 40,
  delivery_fee numeric(12,2) not null default 500,
  commission_percentage numeric(5,2) not null default 15,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.zones (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  factor numeric(6,3) not null default 1.0 check (factor > 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.complaints (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  order_id uuid references public.orders(id) on delete set null,
  subject text not null,
  message text not null,
  status text not null default 'open' check (status in ('open','in_progress','resolved','closed')),
  response text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index orders_customer_idx on public.orders(customer_id, created_at desc);
create index orders_driver_idx on public.orders(driver_id, status, created_at desc);
create index orders_status_idx on public.orders(status, created_at desc);
create index locations_driver_created_idx on public.locations(driver_id, created_at desc);
create index notifications_user_idx on public.notifications(user_id, created_at desc);
create index complaints_user_idx on public.complaints(user_id, created_at desc);

create or replace function public.set_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at=now(); return new; end $$;

do $$ declare t text; begin
  foreach t in array array['profiles','drivers','vehicles','orders','payments','pricing','zones','complaints'] loop
    execute format('create trigger %I_updated_at before update on public.%I for each row execute function public.set_updated_at()', t, t);
  end loop;
end $$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, phone, full_name, role)
  values (new.id, coalesce(new.phone, ''), coalesce(new.raw_user_meta_data->>'full_name',''), 'customer')
  on conflict (id) do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

create or replace function public.prevent_role_change() returns trigger
language plpgsql security definer set search_path=public
as $$
begin
  if old.role is distinct from new.role and not public.is_admin() then
    raise exception 'Role changes are restricted';
  end if;
  return new;
end $$;

create trigger prevent_profile_role_change before update on public.profiles
for each row execute function public.prevent_role_change();

alter table public.profiles enable row level security;
alter table public.drivers enable row level security;
alter table public.vehicles enable row level security;
alter table public.orders enable row level security;
alter table public.trips enable row level security;
alter table public.locations enable row level security;
alter table public.payments enable row level security;
alter table public.ratings enable row level security;
alter table public.notifications enable row level security;
alter table public.pricing enable row level security;
alter table public.zones enable row level security;
alter table public.complaints enable row level security;

create policy profiles_select_self_or_admin on public.profiles for select using (id=auth.uid() or public.is_admin());
create policy profiles_update_self_or_admin on public.profiles for update using (id=auth.uid() or public.is_admin()) with check (id=auth.uid() or public.is_admin());

create policy drivers_select_self_or_admin on public.drivers for select using (profile_id=auth.uid() or public.is_admin());
create policy drivers_update_self_or_admin on public.drivers for update using (profile_id=auth.uid() or public.is_admin()) with check (profile_id=auth.uid() or public.is_admin());
create policy drivers_insert_admin on public.drivers for insert with check (public.is_admin());

create policy vehicles_select_owner_or_admin on public.vehicles for select using (exists(select 1 from public.drivers d where d.id=driver_id and (d.profile_id=auth.uid() or public.is_admin())));
create policy vehicles_update_owner_or_admin on public.vehicles for update using (exists(select 1 from public.drivers d where d.id=driver_id and (d.profile_id=auth.uid() or public.is_admin()))) with check (exists(select 1 from public.drivers d where d.id=driver_id and (d.profile_id=auth.uid() or public.is_admin())));
create policy vehicles_insert_admin on public.vehicles for insert with check (public.is_admin());

create policy orders_select_customer_or_assigned_driver_or_admin on public.orders for select using (
  customer_id=auth.uid() or exists(select 1 from public.drivers d where d.id=driver_id and d.profile_id=auth.uid()) or public.is_admin()
);
create policy orders_update_admin_only on public.orders for update using (public.is_admin()) with check (public.is_admin());

create policy trips_select_participant_or_admin on public.trips for select using (
  public.is_admin() or exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid())
  or exists(select 1 from public.drivers d where d.id=driver_id and d.profile_id=auth.uid())
);

create policy locations_insert_driver on public.locations for insert with check (
  exists(select 1 from public.drivers d where d.id=driver_id and d.profile_id=auth.uid())
);
create policy locations_select_order_participant_or_admin on public.locations for select using (
  public.is_admin() or exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid())
  or exists(select 1 from public.drivers d where d.id=driver_id and d.profile_id=auth.uid())
);

create policy payments_select_participant_or_admin on public.payments for select using (
  public.is_admin() or exists(select 1 from public.orders o where o.id=order_id and o.customer_id=auth.uid())
  or exists(select 1 from public.orders o join public.drivers d on d.id=o.driver_id where o.id=order_id and d.profile_id=auth.uid())
);

create policy ratings_select_participant_or_admin on public.ratings for select using (customer_id=auth.uid() or exists(select 1 from public.drivers d where d.id=driver_id and d.profile_id=auth.uid()) or public.is_admin());
create policy ratings_insert_customer on public.ratings for insert with check (customer_id=auth.uid());

create policy notifications_self on public.notifications for select using (user_id=auth.uid() or public.is_admin());
create policy notifications_update_self on public.notifications for update using (user_id=auth.uid() or public.is_admin()) with check (user_id=auth.uid() or public.is_admin());

create policy pricing_public_read on public.pricing for select using (active=true or public.is_admin());
create policy pricing_admin_write on public.pricing for all using (public.is_admin()) with check (public.is_admin());
create policy zones_public_read on public.zones for select using (active=true or public.is_admin());
create policy zones_admin_write on public.zones for all using (public.is_admin()) with check (public.is_admin());

create policy complaints_self_or_admin on public.complaints for select using (user_id=auth.uid() or public.is_admin());
create policy complaints_insert_self on public.complaints for insert with check (user_id=auth.uid());
create policy complaints_update_admin on public.complaints for update using (public.is_admin()) with check (public.is_admin());

insert into public.pricing(base_fare,price_per_km,price_per_minute,delivery_fee,commission_percentage)
values (1000,450,40,500,15) on conflict do nothing;

insert into public.zones(name,factor) values ('الخرطوم',1.0),('بحري',1.0),('أم درمان',1.0) on conflict do nothing;

create or replace function public.haversine_km(lat1 double precision,lng1 double precision,lat2 double precision,lng2 double precision)
returns double precision language sql immutable as $$
  select 6371 * 2 * asin(sqrt(
    power(sin(radians(lat2-lat1)/2),2) +
    cos(radians(lat1))*cos(radians(lat2))*power(sin(radians(lng2-lng1)/2),2)
  ));
$$;

create or replace function public.create_customer_order(
  p_type text,p_pickup_lat double precision,p_pickup_lng double precision,
  p_destination_lat double precision,p_destination_lng double precision,
  p_distance_km numeric,p_duration_min integer,p_estimated_fare numeric,
  p_delivery_category text default null,p_notes text default null
) returns public.orders
language plpgsql security definer set search_path=public
as $$
declare
  new_order public.orders;
  chosen_driver uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_type not in ('ride','delivery') then raise exception 'Invalid order type'; end if;
  if p_estimated_fare < 0 or p_distance_km < 0 or p_duration_min < 0 then raise exception 'Invalid fare data'; end if;

  select d.id into chosen_driver
  from public.drivers d
  join lateral (
    select l.lat,l.lng from public.locations l
    where l.driver_id=d.id order by l.created_at desc limit 1
  ) l on true
  where d.status='approved' and d.online=true and d.active=true
  order by public.haversine_km(p_pickup_lat,p_pickup_lng,l.lat,l.lng)
  limit 1;

  insert into public.orders(
    customer_id,driver_id,type,status,pickup_lat,pickup_lng,destination_lat,destination_lng,
    distance_km,duration_min,estimated_fare,payment_method,delivery_category,notes
  ) values (
    auth.uid(),chosen_driver,p_type,
    case when chosen_driver is null then 'searching_driver' else 'searching_driver' end,
    p_pickup_lat,p_pickup_lng,p_destination_lat,p_destination_lng,
    p_distance_km,p_duration_min,p_estimated_fare,'cash',p_delivery_category,p_notes
  ) returning * into new_order;

  insert into public.payments(order_id,method,amount,status)
  values(new_order.id,'cash',p_estimated_fare,'pending');

  if chosen_driver is not null then
    insert into public.notifications(user_id,title,body)
    select d.profile_id,'طلب جديد','لديك طلب جديد قريب من موقعك.'
    from public.drivers d where d.id=chosen_driver;
  end if;
  return new_order;
end $$;

create or replace function public.transition_order(p_order_id uuid,p_new_status text)
returns public.orders
language plpgsql security definer set search_path=public
as $$
declare
  o public.orders; d public.drivers; updated public.orders;
begin
  select * into o from public.orders where id=p_order_id for update;
  if not found then raise exception 'Order not found'; end if;
  if o.status='completed' or o.status='cancelled' then raise exception 'Order is closed'; end if;

  if o.customer_id=auth.uid() then
    if p_new_status <> 'cancelled' then raise exception 'Customer may only cancel an active order'; end if;
  else
    select * into d from public.drivers where id=o.driver_id;
    if d.profile_id is distinct from auth.uid() and not public.is_admin() then raise exception 'Not allowed'; end if;
    if p_new_status='driver_assigned' and o.status<>'searching_driver' then raise exception 'Invalid transition'; end if;
  end if;

  if not (
    (o.status='pending' and p_new_status in ('searching_driver','cancelled')) or
    (o.status='searching_driver' and p_new_status in ('driver_assigned','cancelled')) or
    (o.status='driver_assigned' and p_new_status in ('driver_arriving','cancelled')) or
    (o.status='driver_arriving' and p_new_status in ('arrived_pickup','cancelled')) or
    (o.status='arrived_pickup' and p_new_status in ('picked_up','cancelled')) or
    (o.status='picked_up' and p_new_status in ('on_the_way','cancelled')) or
    (o.status='on_the_way' and p_new_status in ('arrived_destination','cancelled')) or
    (o.status='arrived_destination' and p_new_status='completed')
  ) then raise exception 'Invalid order transition'; end if;

  update public.orders set status=p_new_status,
    final_fare=case when p_new_status='completed' then estimated_fare else final_fare end,
    cancelled_by=case when p_new_status='cancelled' then auth.uid() else cancelled_by end
  where id=p_order_id returning * into updated;

  if p_new_status='driver_assigned' then
    insert into public.trips(order_id,driver_id) values(updated.id,updated.driver_id)
    on conflict(order_id) do nothing;
  elsif p_new_status='driver_arriving' then
    update public.trips set started_at=coalesce(started_at,now()) where order_id=updated.id;
  elsif p_new_status='arrived_pickup' then
    update public.trips set arrived_pickup_at=now() where order_id=updated.id;
  elsif p_new_status='picked_up' then
    update public.trips set picked_up_at=now() where order_id=updated.id;
  elsif p_new_status='on_the_way' then
    update public.trips set started_at=coalesce(started_at,now()) where order_id=updated.id;
  elsif p_new_status='arrived_destination' then
    update public.trips set arrived_destination_at=now() where order_id=updated.id;
  elsif p_new_status='completed' then
    update public.trips set completed_at=now() where order_id=updated.id;
    update public.drivers set total_trips=total_trips+1 where id=updated.driver_id;
    update public.payments set status='paid',paid_at=now() where order_id=updated.id and method='cash';
  end if;

  if updated.customer_id is not null then
    insert into public.notifications(user_id,title,body)
    values(updated.customer_id,'تحديث الطلب','تم تحديث حالة طلبك إلى '||p_new_status);
  end if;
  return updated;
end $$;

create or replace function public.driver_reject_order(p_order_id uuid)
returns public.orders
language plpgsql security definer set search_path=public
as $$
declare o public.orders; new_driver uuid; updated public.orders;
begin
  select * into o from public.orders where id=p_order_id for update;
  if o.status<>'searching_driver' then raise exception 'Order is not waiting for driver'; end if;
  if not exists(select 1 from public.drivers d where d.id=o.driver_id and d.profile_id=auth.uid()) then raise exception 'Not assigned driver'; end if;

  select d.id into new_driver
  from public.drivers d
  join lateral (select l.lat,l.lng from public.locations l where l.driver_id=d.id order by l.created_at desc limit 1) l on true
  where d.status='approved' and d.online=true and d.active=true and d.id<>o.driver_id
  order by public.haversine_km(o.pickup_lat,o.pickup_lng,l.lat,l.lng)
  limit 1;

  update public.orders set driver_id=new_driver where id=o.id returning * into updated;
  if new_driver is not null then
    insert into public.notifications(user_id,title,body)
    select d.profile_id,'طلب جديد','تم توجيه طلب جديد إليك.' from public.drivers d where d.id=new_driver;
  end if;
  return updated;
end $$;

grant execute on function public.create_customer_order(text,double precision,double precision,double precision,double precision,numeric,integer,numeric,text,text) to authenticated;
grant execute on function public.transition_order(uuid,text) to authenticated;
grant execute on function public.driver_reject_order(uuid) to authenticated;

alter publication supabase_realtime add table public.orders;
alter publication supabase_realtime add table public.notifications;
alter publication supabase_realtime add table public.locations;
