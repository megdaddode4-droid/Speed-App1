-- Prevent clients from inserting arbitrary ratings directly.
-- Production clients must use submit_rating(), which validates ownership,
-- completion state and the assigned driver before writing the rating.
drop policy if exists ratings_insert_customer on public.ratings;

revoke insert on public.ratings from authenticated;
grant execute on function public.submit_rating(uuid,integer,text) to authenticated;
