create or replace function public.prevent_driver_privileged_change() returns trigger
language plpgsql security definer set search_path=public
as $$
begin
  if not public.is_admin() then
    if old.profile_id is distinct from new.profile_id
       or old.status is distinct from new.status
       or old.rating is distinct from new.rating
       or old.total_trips is distinct from new.total_trips
       or old.active is distinct from new.active then
      raise exception 'Driver profile changes require admin privileges';
    end if;
  end if;
  return new;
end $$;

create trigger prevent_driver_privileged_change
before update on public.drivers
for each row execute function public.prevent_driver_privileged_change();

create or replace function public.submit_rating(p_order_id uuid,p_rating integer,p_comment text default null)
returns public.ratings
language plpgsql security definer set search_path=public
as $$
declare o public.orders; r public.ratings;
begin
  select * into o from public.orders where id=p_order_id;
  if o.customer_id<>auth.uid() or o.status<>'completed' or o.driver_id is null then
    raise exception 'Rating not allowed';
  end if;
  insert into public.ratings(order_id,customer_id,driver_id,rating,comment)
  values(o.id,auth.uid(),o.driver_id,p_rating,p_comment)
  returning * into r;
  update public.drivers d set rating = (
    select round(avg(x.rating)::numeric,2) from public.ratings x where x.driver_id=d.id
  ) where d.id=o.driver_id;
  return r;
end $$;

grant execute on function public.submit_rating(uuid,integer,text) to authenticated;
