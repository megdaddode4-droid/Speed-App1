import { createClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_SEED_URL || process.env.SUPABASE_URL;
const serviceRole = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !serviceRole) throw new Error('Set SUPABASE_SEED_URL (or SUPABASE_URL) and SUPABASE_SERVICE_ROLE_KEY.');

const sb = createClient(url, serviceRole, { auth: { autoRefreshToken: false, persistSession: false } });
const customers = ['0911000001','0911000002','0911000003','0911000004','0911000005'];
const drivers = ['0911000101','0911000102','0911000103','0911000104','0911000105','0911000106','0911000107','0911000108','0911000109','0911000110'];
const admin = '0911000999';

async function ensureUser(phone:string,name:string){
  const {data,error}=await sb.auth.admin.createUser({phone,phone_confirm:true,user_metadata:{full_name:name}});
  if (error && !error.message.toLowerCase().includes('already')) throw error;
  if(data.user) return data.user.id;
  const {data:list,error:e}=await sb.auth.admin.listUsers({perPage:1000});
  if(e)throw e;
  const found=list.users.find(u=>u.phone===phone); if(!found)throw new Error(`Could not resolve ${phone}`); return found.id;
}
async function main(){
  const customerIds=[]; for(let i=0;i<customers.length;i++) customerIds.push(await ensureUser(customers[i],`عميل ${i+1}`));
  const driverProfileIds=[]; for(let i=0;i<drivers.length;i++) driverProfileIds.push(await ensureUser(drivers[i],`سائق ${i+1}`));
  const adminId=await ensureUser(admin,'مدير سرعة');
  await sb.from('profiles').update({role:'admin',full_name:'مدير سرعة'}).eq('id',adminId);
  const driverRows=[]; for(let i=0;i<driverProfileIds.length;i++){
    const {data:existing}=await sb.from('drivers').select('id').eq('profile_id',driverProfileIds[i]).maybeSingle();
    let driverId=existing?.id;
    if(!driverId){const {data,error}=await sb.from('drivers').insert({profile_id:driverProfileIds[i],status:'approved',online:i<5,active:true,rating:4.5,total_trips:i*7,license_number:`SD-${1000+i}`}).select('id').single();if(error)throw error;driverId=data.id}
    driverRows.push(driverId);
    const {count}=await sb.from('vehicles').select('id',{count:'exact',head:true}).eq('driver_id',driverId);
    if(!count){const {error}=await sb.from('vehicles').insert({driver_id:driverId,type:i%3===0?'scooter':i%3===1?'bike':'bicycle',make:'Demo',model:`M-${i+1}`,color:i%2?'أحمر':'أسود',plate_number:`S-${200+i}`,active:true});if(error)throw error}
    await sb.from('locations').insert({driver_id:driverId,lat:15.50+i*0.003,lng:32.56+i*0.003});
  }
  const statuses=['completed','completed','driver_assigned','on_the_way','cancelled','arrived_pickup','completed','searching_driver','driver_arriving','completed','cancelled','picked_up','completed','completed','pending','completed','arrived_destination','completed','driver_assigned','completed'];
  for(let i=0;i<20;i++){
    const d=driverRows[i%driverRows.length];
    const status=statuses[i];
    const {data:o,error}=await sb.from('orders').insert({
      customer_id:customerIds[i%customerIds.length],driver_id:status==='pending'||status==='searching_driver'?null:d,
      type:i%4===0?'delivery':'ride',status,pickup_lat:15.48+(i%5)*.01,pickup_lng:32.53+(i%5)*.01,
      destination_lat:15.52+(i%4)*.01,destination_lng:32.57+(i%4)*.01,distance_km:2.5+i*.25,
      duration_min:10+i,estimated_fare:2500+i*250,final_fare:status==='completed'||status==='arrived_destination'?2500+i*250:null,
      payment_method:'cash',delivery_category:i%4===0?'طعام':null,notes:null
    }).select('id').single();
    if(error)throw error;
    if(o) await sb.from('payments').upsert({order_id:o.id,method:'cash',amount:2500+i*250,status:status==='completed'?'paid':'pending'});
    if(status!=='pending'&&status!=='searching_driver') await sb.from('trips').upsert({order_id:o!.id,driver_id:d});
  }
  console.log('Seed complete: 5 customers, 10 drivers, 10 vehicles, 20 orders, 1 admin.');
}
main().catch(e=>{console.error(e);process.exit(1)});
