import { BrowserRouter } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ConnectivityProvider } from './contexts/ConnectivityContext';
import { AppRouter } from './routes/AppRouter';
import { Splash } from './components/Splash';

export default function App() {
  return <BrowserRouter><AuthProvider><ConnectivityProvider><Splash><AppRouter /></Splash></ConnectivityProvider></AuthProvider></BrowserRouter>;
}