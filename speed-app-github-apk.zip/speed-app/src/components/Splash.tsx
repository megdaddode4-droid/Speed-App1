import { useEffect, useState } from 'react';
export function Splash({ children }: { children: React.ReactNode }) {
  const [show,setShow]=useState(true);
  useEffect(()=>{const t=setTimeout(()=>setShow(false),650);return()=>clearTimeout(t)},[]);
  return show?<div className="auth-page"><div className="brand big">سرعة</div></div>:<>{children}</>;
}