import type { OrderStatus } from '../types';
const labels: Record<OrderStatus,string> = {
 pending:'قيد الإنشاء', searching_driver:'جاري البحث عن سائق', driver_assigned:'تم تعيين السائق',
 driver_arriving:'السائق في الطريق', arrived_pickup:'وصل السائق', picked_up:'تم الاستلام',
 on_the_way:'في الطريق', arrived_destination:'وصل للوجهة', completed:'مكتمل', cancelled:'ملغي'
};
export function StatusPill({ status }: { status: OrderStatus }) { return <span className={`pill status-${status}`}>{labels[status]}</span>; }