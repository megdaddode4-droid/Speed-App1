import { MapContainer, Marker, Polyline, TileLayer } from 'react-leaflet';
import L from 'leaflet';
import type { Coordinates } from '../types';

const pin=(kind:string)=>L.divIcon({className:`map-pin ${kind}`,html:'<span></span>',iconSize:[24,24],iconAnchor:[12,12]});
export function OrderMap({pickup,destination,driver}:{pickup:Coordinates;destination:Coordinates;driver?:Coordinates}){
  const center=driver??pickup;
  return <div className="map-wrap"><MapContainer center={[center.lat,center.lng]} zoom={13} scrollWheelZoom><TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/><Marker position={[pickup.lat,pickup.lng]} icon={pin('pickup')}/><Marker position={[destination.lat,destination.lng]} icon={pin('destination')}/>{driver&&<Marker position={[driver.lat,driver.lng]} icon={pin('driver')}/>}<Polyline positions={[[pickup.lat,pickup.lng],[destination.lat,destination.lng]]}/></MapContainer></div>;
}