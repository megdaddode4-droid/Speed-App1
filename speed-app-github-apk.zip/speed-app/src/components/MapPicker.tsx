import { MapContainer, Marker, TileLayer, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import type { Coordinates } from '../types';

const icon = L.divIcon({ className: 'map-pin', html: '<span></span>', iconSize: [24,24], iconAnchor: [12,12] });

function Clicker({ onPick }: { onPick: (c: Coordinates) => void }) {
  useMapEvents({ click(e) { onPick({ lat: e.latlng.lat, lng: e.latlng.lng }); } });
  return null;
}
export function MapPicker({ value, onPick, label='اختر الموقع' }: { value?: Coordinates; onPick: (c: Coordinates)=>void; label?: string }) {
  const center = value ?? { lat: 15.5007, lng: 32.5599 };
  return <div className="map-wrap" aria-label={label}>
    <MapContainer center={[center.lat, center.lng]} zoom={13} scrollWheelZoom>
      <TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      <Clicker onPick={onPick} />
      {value && <Marker position={[value.lat,value.lng]} icon={icon} />}
    </MapContainer>
  </div>;
}