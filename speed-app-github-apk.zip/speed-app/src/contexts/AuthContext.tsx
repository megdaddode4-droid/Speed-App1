import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Profile, Role } from '../types';
import { supabase } from '../lib/supabase';
import { env } from '../lib/env';
import { demoProfiles } from '../data/demo';
import { getDemoProfile } from '../services/demoStore';

type AuthState={profile:Profile|null;loading:boolean;signInWithOtp:(phone:string)=>Promise<void>;verifyOtp:(phone:string,token:string)=>Promise<void>;signOut:()=>Promise<void>;demoRole:(role:Role)=>void};
const Ctx=createContext<AuthState>(null!);
const rolePhones:Record<Role,string>={customer:'0911000001',driver:'0911000101',admin:'0911000999'};
export function AuthProvider({children}:{children:ReactNode}){
 const [profile,setProfile]=useState<Profile|null>(null);const [loading,setLoading]=useState(true);
 const loadProfile=async(userId:string)=>{if(!supabase)return;const {data}=await supabase.from('profiles').select('*').eq('id',userId).single();if(data)setProfile(data as Profile)};
 useEffect(()=>{if(env.demoMode){const saved=localStorage.getItem('sar3a-demo-user');if(saved)setProfile(getDemoProfile(saved));setLoading(false);return;}if(!supabase){setLoading(false);return;}supabase.auth.getSession().then(({data})=>{if(data.session?.user)void loadProfile(data.session.user.id);else setLoading(false)});const {data:l}=supabase.auth.onAuthStateChange((_e,session)=>{if(session?.user)void loadProfile(session.user.id);else setProfile(null)});return()=>l.subscription.unsubscribe()},[]);
 const signInWithOtp=async(phone:string)=>{if(env.demoMode){const p=getDemoProfile(phone);if(!p)throw new Error('رقم غير موجود في وضع التجربة. استخدم أحد أرقام Demo.');localStorage.setItem('sar3a-demo-user',phone);setProfile(p);return;}if(!supabase)throw new Error('أكمل إعداد Supabase أولاً.');const {error}=await supabase.auth.signInWithOtp({phone});if(error)throw error};
 const verifyOtp=async(phone:string,token:string)=>{if(env.demoMode){if(token!=='123456')throw new Error('في وضع التجربة استخدم 123456.');const p=getDemoProfile(phone);if(p)setProfile(p);return;}if(!supabase)throw new Error('أكمل إعداد Supabase أولاً.');const {data,error}=await supabase.auth.verifyOtp({phone,token,type:'sms'});if(error)throw error;if(data.user)await loadProfile(data.user.id)};
 const demoRole=(role:Role)=>{const p=getDemoProfile(rolePhones[role]);if(p){localStorage.setItem('sar3a-demo-user',p.phone);setProfile(p)}};
 const signOut=async()=>{if(!env.demoMode&&supabase)await supabase.auth.signOut();localStorage.removeItem('sar3a-demo-user');setProfile(null)};
 return <Ctx.Provider value={{profile,loading,signInWithOtp,verifyOtp,signOut,demoRole}}>{children}</Ctx.Provider>;
}
export const useAuth=()=>useContext(Ctx);
