import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

const Ctx = createContext({ online: navigator.onLine });

export function ConnectivityProvider({ children }: { children: ReactNode }) {
  const [online, setOnline] = useState(navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true), off = () => setOnline(false);
    addEventListener('online', on); addEventListener('offline', off);
    return () => { removeEventListener('online', on); removeEventListener('offline', off); };
  }, []);
  return <Ctx.Provider value={{ online }}>{children}</Ctx.Provider>;
}
export const useConnectivity = () => useContext(Ctx);