import { supabase } from '../lib/supabase';
export async function submitRating(orderId: string, rating: number, comment?: string) {
  if (!supabase) throw new Error('Supabase غير مهيأ.');
  const { data, error } = await supabase.rpc('submit_rating', { p_order_id: orderId, p_rating: rating, p_comment: comment ?? null });
  if (error) throw error;
  return data;
}