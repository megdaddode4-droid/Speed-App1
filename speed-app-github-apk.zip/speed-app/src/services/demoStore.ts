import type { Driver, Order, Profile, Pricing, Vehicle, OrderStatus } from '../types';
import { demoDrivers, demoOrders, demoPricing, demoProfiles, demoVehicles } from '../data/demo';

const KEY='sar3a-demo-v2';
type State={profiles:Profile[];drivers:Driver[];vehicles:Vehicle[];orders:Order[];pricing:Pricing;notifications:{id:string;user_id:string;title:string;body:string;read_at:string|null;created_at:string}[]};

function initial():State{
  const now=new Date().toISOString();
  const drivers=demoDrivers.map((d,i)=>({...d,profile_id:`demo-driver-profile-${i+1}`}));
  const driverProfiles:Profile[]=drivers.map((d,i)=>({id:d.profile_id,phone:`091100010${i+1}`,full_name:['محمد أحمد','عبدالرحمن علي','مصعب خالد'][i]||`سائق ${i+1}`,role:'driver',avatar_url:null,created_at:now,updated_at:now}));
  const admin:Profile={id:'demo-admin',phone:'0911000999',full_name:'مدير سرعة',role:'admin',avatar_url:null,created_at:now,updated_at:now};
  return {profiles:[...demoProfiles,...driverProfiles,admin],drivers,vehicles:demoVehicles,orders:[...demoOrders],pricing:demoPricing[0],notifications:[]};
}
function read(){try{const raw=localStorage.getItem(KEY);if(raw)return JSON.parse(raw) as State}catch{} const s=initial();localStorage.setItem(KEY,JSON.stringify(s));return s}
function write(s:State){localStorage.setItem(KEY,JSON.stringify(s));window.dispatchEvent(new Event('sar3a-demo-change'));return s}
export function resetDemo(){localStorage.removeItem(KEY);write(initial())}
export function getDemoState(){return read()}
export function getDemoProfile(phone:string){return read().profiles.find(p=>p.phone===phone)||null}
export function listDemoOrders(customerId?:string){const rows=read().orders;return customerId?rows.filter(o=>o.customer_id===customerId).sort((a,b)=>b.created_at.localeCompare(a.created_at)):rows.sort((a,b)=>b.created_at.localeCompare(a.created_at))}
export function listDriverOrders(driverId:string){return read().orders.filter(o=>o.driver_id===driverId).sort((a,b)=>b.created_at.localeCompare(a.created_at))}
export function createDemoOrder(input:{customerId:string;type:'ride'|'delivery';pickup:{lat:number;lng:number};destination:{lat:number;lng:number};distanceKm:number;durationMin:number;estimatedFare:number;deliveryCategory?:string;notes?:string}){
  const s=read(); const now=new Date().toISOString(); const order:Order={id:`demo-order-${Date.now()}`,customer_id:input.customerId,driver_id:null,type:input.type,status:'searching_driver',pickup_lat:input.pickup.lat,pickup_lng:input.pickup.lng,destination_lat:input.destination.lat,destination_lng:input.destination.lng,distance_km:input.distanceKm,duration_min:input.durationMin,estimated_fare:input.estimatedFare,final_fare:null,payment_method:'cash',delivery_category:input.deliveryCategory??null,notes:input.notes??null,created_at:now,updated_at:now};
  const nearest=s.drivers.filter(d=>d.online&&d.active&&d.status==='approved').sort((a,b)=>Number(b.online)-Number(a.online))[0];
  if(nearest){order.driver_id=nearest.id;order.status='driver_assigned';}
  s.orders.unshift(order);s.notifications.unshift({id:`n-${Date.now()}`,user_id:input.customerId,title:nearest?'تم العثور على سائق':'جاري البحث عن سائق',body:nearest?'تم تعيين سائق قريب لطلبك.':'سنواصل البحث عن أقرب سائق.',read_at:null,created_at:now});write(s);return order;
}
const allowed:Record<OrderStatus,OrderStatus[]>={pending:['searching_driver','cancelled'],searching_driver:['driver_assigned','cancelled'],driver_assigned:['driver_arriving','cancelled'],driver_arriving:['arrived_pickup','cancelled'],arrived_pickup:['picked_up','cancelled'],picked_up:['on_the_way','cancelled'],on_the_way:['arrived_destination','cancelled'],arrived_destination:['completed','cancelled'],completed:[],cancelled:[]};
export function transitionDemoOrder(id:string,next:OrderStatus){const s=read();const o=s.orders.find(x=>x.id===id);if(!o||!allowed[o.status].includes(next))throw new Error('انتقال الحالة غير مسموح.');o.status=next;o.updated_at=new Date().toISOString();if(next==='completed')o.final_fare=o.estimated_fare;write(s);return {...o}}
export function assignDemoOrder(id:string,driverId:string){const s=read();const o=s.orders.find(x=>x.id===id);if(!o)throw new Error('الطلب غير موجود.');o.driver_id=driverId;o.status='driver_assigned';o.updated_at=new Date().toISOString();write(s);return {...o}}
export function setDriverOnline(driverId:string,online:boolean){const s=read();const d=s.drivers.find(x=>x.id===driverId);if(d){d.online=online;write(s)}return d?{...d}:null}
export function updateDemoPricing(patch:Partial<Pricing>){const s=read();s.pricing={...s.pricing,...patch};write(s);return s.pricing}
export function getDemoNotifications(userId:string){return read().notifications.filter(n=>n.user_id===userId).sort((a,b)=>b.created_at.localeCompare(a.created_at))}
export function seedRichDemo(){const s=read();if(s.orders.length>=8)return;const customer=s.profiles.find(p=>p.role==='customer')!;for(let i=0;i<10;i++){const base=15.49+i*.003;const order:Order={id:`seed-order-${i+1}`,customer_id:customer.id,driver_id:i<6?s.drivers[i%3].id:null,type:i%3===0?'delivery':'ride',status:(['completed','completed','driver_arriving','on_the_way','cancelled','arrived_destination','searching_driver','driver_assigned','picked_up','pending'] as OrderStatus[])[i],pickup_lat:base,pickup_lng:32.55+i*.002,destination_lat:15.51+i*.002,destination_lng:32.58+i*.002,distance_km:2.5+i*.6,duration_min:10+i*2,estimated_fare:2200+i*350,final_fare:i<2?2200+i*350:null,payment_method:'cash',delivery_category:i%3===0?'طعام':null,notes:null,created_at:new Date(Date.now()-i*3600000).toISOString(),updated_at:new Date(Date.now()-i*3600000).toISOString()};s.orders.push(order)}write(s)}
export function getDemoDriver(id:string){return read().drivers.find(d=>d.id===id)||null}
export function getDemoVehicle(driverId:string){return read().vehicles.find(v=>v.driver_id===driverId)||null}
export function getDemoProfiles(){return read().profiles}
export function updateDemoDriverStatus(id:string,status:Driver['status']){const s=read();const d=s.drivers.find(x=>x.id===id);if(d){d.status=status;d.online=status!=='approved'?false:d.online;write(s)}return d}
export function getDemoPricing(){return read().pricing}
