import { supabase } from '../lib/supabase';

export const GPS_INTERVAL_MS = 7000;
export const GPS_MIN_DISTANCE_METERS = 30;

export function watchDriverLocation(driverId: string, orderId?: string, onPosition?: (lat: number, lng: number) => void) {
  if (!navigator.geolocation) throw new Error('الموقع الجغرافي غير مدعوم.');
  let last: { lat: number; lng: number } | null = null;
  const distance = (a: {lat:number;lng:number}, b:{lat:number;lng:number}) => {
    const R = 6371000, p1=a.lat*Math.PI/180, p2=b.lat*Math.PI/180, dp=(b.lat-a.lat)*Math.PI/180, dl=(b.lng-a.lng)*Math.PI/180;
    const x=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
    return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
  };
  const id = navigator.geolocation.watchPosition(async pos => {
    const lat=pos.coords.latitude,lng=pos.coords.longitude;
    if (last && distance(last,{lat,lng}) < GPS_MIN_DISTANCE_METERS) return;
    last={lat,lng}; onPosition?.(lat,lng);
    if (supabase) await supabase.from('locations').insert({ driver_id: driverId, order_id: orderId ?? null, lat, lng, accuracy_m: pos.coords.accuracy });
  }, console.error, { enableHighAccuracy: false, maximumAge: 5000, timeout: 10000 });
  return () => navigator.geolocation.clearWatch(id);
}