import { supabase } from '../lib/supabase';

export function subscribeToOrder(orderId: string, onChange: (payload: unknown) => void) {
  if (!supabase) return () => {};
  const channel = supabase.channel(`order:${orderId}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `id=eq.${orderId}` }, onChange)
    .subscribe();
  return () => { void supabase.removeChannel(channel); };
}

export function subscribeToDriverRequests(driverId: string, onChange: (payload: unknown) => void) {
  if (!supabase) return () => {};
  const channel = supabase.channel(`driver:${driverId}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'orders', filter: `driver_id=eq.${driverId}` }, onChange)
    .subscribe();
  return () => { void supabase.removeChannel(channel); };
}

export function subscribeToOrderLocations(orderId: string, onChange: (payload: unknown) => void) {
  if (!supabase) return () => {};
  const channel = supabase.channel(`locations:${orderId}`)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'locations', filter: `order_id=eq.${orderId}` }, onChange)
    .subscribe();
  return () => { void supabase.removeChannel(channel); };
}