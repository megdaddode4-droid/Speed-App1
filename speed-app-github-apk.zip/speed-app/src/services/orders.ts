import { supabase } from '../lib/supabase';
import { env } from '../lib/env';
import type { Coordinates, Order, OrderStatus, OrderType } from '../types';

const allowed: Record<OrderStatus, OrderStatus[]> = {
  pending: ['searching_driver','cancelled'],
  searching_driver: ['driver_assigned','cancelled'],
  driver_assigned: ['driver_arriving','cancelled'],
  driver_arriving: ['arrived_pickup','cancelled'],
  arrived_pickup: ['picked_up','cancelled'],
  picked_up: ['on_the_way','cancelled'],
  on_the_way: ['arrived_destination','cancelled'],
  arrived_destination: ['completed','cancelled'],
  completed: [], cancelled: []
};

export function canTransition(from: OrderStatus, to: OrderStatus) { return allowed[from]?.includes(to) ?? false; }

export async function createOrder(input: {
  customerId: string; type: OrderType; pickup: Coordinates; destination: Coordinates;
  distanceKm: number; durationMin: number; estimatedFare: number; deliveryCategory?: string; notes?: string;
}) {
  if (env.demoMode) {
    return { id: `demo-order-${Date.now()}`, ...input, status: 'searching_driver' as OrderStatus };
  }
  if (!supabase) throw new Error('Supabase غير مهيأ.');
  const { data, error } = await supabase.rpc('create_customer_order', {
    p_type: input.type, p_pickup_lat: input.pickup.lat, p_pickup_lng: input.pickup.lng,
    p_destination_lat: input.destination.lat, p_destination_lng: input.destination.lng,
    p_distance_km: input.distanceKm, p_duration_min: input.durationMin,
    p_estimated_fare: input.estimatedFare, p_delivery_category: input.deliveryCategory ?? null,
    p_notes: input.notes ?? null
  });
  if (error) throw error;
  return data as Order;
}

export async function updateOrderStatus(orderId: string, status: OrderStatus) {
  if (!supabase) throw new Error('Supabase غير مهيأ.');
  const { data, error } = await supabase.rpc('transition_order', { p_order_id: orderId, p_new_status: status });
  if (error) throw error;
  return data;
}

export async function rejectOrder(orderId: string) {
  if (!supabase) throw new Error('Supabase غير مهيأ.');
  const { data, error } = await supabase.rpc('driver_reject_order', { p_order_id: orderId });
  if (error) throw error;
  return data;
}

export async function listCustomerOrders(customerId: string) {
  if (!supabase) return [];
  const { data, error } = await supabase.from('orders').select('*').eq('customer_id', customerId).order('created_at', { ascending: false }).limit(50);
  if (error) throw error; return data as Order[];
}