import { supabase } from '../lib/supabase';
import { demoPricing } from '../data/demo';
import type { Pricing } from '../types';

export function calculateFare(p: Pricing, distanceKm: number, durationMin: number, isDelivery: boolean) {
  const subtotal = p.base_fare + distanceKm * p.price_per_km + durationMin * p.price_per_minute;
  return Math.round(subtotal + (isDelivery ? p.delivery_fee : 0));
}
export async function getActivePricing(): Promise<Pricing> {
  if (!supabase) return demoPricing[0];
  const { data, error } = await supabase.from('pricing').select('*').eq('active', true).order('created_at', { ascending: false }).limit(1).single();
  if (error) throw error;
  return data as Pricing;
}