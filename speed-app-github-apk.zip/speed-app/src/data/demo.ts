import type { Driver, Order, Pricing, Profile, Vehicle } from '../types';
const now=new Date().toISOString();
export const demoProfiles: Profile[]=Array.from({length:5},(_,i)=>({id:`demo-customer-${i+1}`,phone:`091100000${i+1}`,full_name:['أحمد محمد','سارة علي','محمد حسن','مريم خالد','مصعب عمر'][i],role:'customer',avatar_url:null,created_at:now,updated_at:now}));
export const demoDrivers: Driver[]=Array.from({length:10},(_,i)=>({id:`demo-driver-${i+1}`,profile_id:`demo-driver-profile-${i+1}`,status:i<8?'approved':'pending',online:i===0,active:true,rating:4.4+(i%6)*.1,total_trips:40+i*11,license_number:`SD-${100+i}`}));
export const demoVehicles: Vehicle[]=demoDrivers.map((d,i)=>({id:`demo-vehicle-${i+1}`,driver_id:d.id,type:i%3===0?'scooter':i%3===1?'bike':'bicycle',make:i%2?'Honda':'NIU',model:i%3===0?'NQi':'City',color:i%2?'أحمر':'أسود',plate_number:`S-${200+i}`,active:true}));
export const demoPricing: Pricing[]=[{id:'demo-pricing',base_fare:1000,price_per_km:450,price_per_minute:40,delivery_fee:500,commission_percentage:15,active:true}];
export const demoOrders: Order[]=[];
