export type Role = 'customer' | 'driver' | 'admin';
export type OrderType = 'ride' | 'delivery';
export type OrderStatus =
  | 'pending' | 'searching_driver' | 'driver_assigned' | 'driver_arriving'
  | 'arrived_pickup' | 'picked_up' | 'on_the_way' | 'arrived_destination'
  | 'completed' | 'cancelled';
export type DriverStatus = 'pending' | 'approved' | 'rejected' | 'suspended';

export interface Profile {
  id: string; phone: string; full_name: string | null; role: Role;
  avatar_url: string | null; created_at: string; updated_at: string;
}
export interface Driver {
  id: string; profile_id: string; status: DriverStatus; online: boolean; active: boolean;
  rating: number; total_trips: number; license_number: string | null;
}
export interface Vehicle {
  id: string; driver_id: string; type: 'bike' | 'scooter' | 'bicycle'; make: string | null;
  model: string | null; color: string | null; plate_number: string | null; active: boolean;
}
export interface Coordinates { lat: number; lng: number; }
export interface Order {
  id: string; customer_id: string; driver_id: string | null; type: OrderType; status: OrderStatus;
  pickup_lat: number; pickup_lng: number; destination_lat: number; destination_lng: number;
  distance_km: number; duration_min: number; estimated_fare: number; final_fare: number | null;
  payment_method: 'cash' | 'mobile_money' | 'bank_transfer' | 'online';
  delivery_category: string | null; notes: string | null; created_at: string; updated_at: string;
}
export interface Pricing {
  id: string; base_fare: number; price_per_km: number; price_per_minute: number;
  delivery_fee: number; commission_percentage: number; active: boolean;
}
export interface Notification {
  id: string; user_id: string; title: string; body: string; read_at: string | null; created_at: string;
}
