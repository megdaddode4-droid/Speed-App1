export const env = {
  supabaseUrl: import.meta.env.VITE_SUPABASE_URL as string | undefined,
  supabaseAnonKey: import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined,
  demoMode: String(import.meta.env.VITE_DEMO_MODE).toLowerCase() === 'true',
  appName: import.meta.env.VITE_APP_NAME || 'سرعة'
};

export const hasSupabase = Boolean(env.supabaseUrl && env.supabaseAnonKey);