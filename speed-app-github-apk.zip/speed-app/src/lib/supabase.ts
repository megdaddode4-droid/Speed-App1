import { createClient } from '@supabase/supabase-js';
import { env, hasSupabase } from './env';

export const supabase = hasSupabase
  ? createClient(env.supabaseUrl!, env.supabaseAnonKey!, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
      realtime: { params: { eventsPerSecond: 5 } }
    })
  : null;